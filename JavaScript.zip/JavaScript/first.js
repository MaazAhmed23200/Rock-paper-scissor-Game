

let userscore = 0;
let comscore=0;



const choices = document.querySelectorAll(".choice");

const msg = document.querySelector("#msg"); 

const userscorepara = document.querySelector("#your-score");
const comscorepara = document.querySelector("#com-score");
const drawgame = ()=>{
    msg.innerText = "Draw, Try Again";
    msg.style.backgroundColor = "black"

}

const showwinner = (userwin, userchoice, comchoice)=>{
     if(userwin){
        userscore++;
        userscorepara.innerText = userscore;
        msg.innerText = `You Win, your ${userchoice} beats ${comchoice}`;
       

        msg.style.backgroundColor = "green";
     }else{
        comscore++;
        comscorepara.innerText = comscore;
        msg.innerText = `You Lose, ${comchoice} beats your ${userchoice}`;
        msg.style.backgroundColor = "red";
     }
}

const gecomchoice = ()=>{
    const option=["rock","paper","scissor"];
    const randomIdx = Math.floor(Math.random() * 3);
    return option[randomIdx];
}
const playgame = (userchoice)=>{

       const comchoice = gecomchoice();
       if(userchoice==comchoice){
 
        drawgame();
       }else{
        let userwin = true;
        if(userchoice==="rock"){
            userwin = comchoice === "paper" ? false : true;
        }else if(userchoice==="paper"){
            userwin = comchoice === "scissor" ? false : true;
        }else{
            userwin = comchoice === "rock" ? false : true;  
        }
          showwinner(userwin, userchoice, comchoice);
       }
};
   
   choices.forEach((choice) => {
         choice.addEventListener("click", () => {
            const userchoice = choice.getAttribute("id");

            
            playgame(userchoice);
         });
   });









